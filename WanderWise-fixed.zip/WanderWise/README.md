# WanderWise (fixed version)

Single-file site: just `index.html`. Design and layout are unchanged.

## Put it online (Netlify)
1. Go to https://app.netlify.com/drop
2. Drag this folder (or just `index.html`) onto the page.
3. To update your existing site instead: Site → Deploys → drag the folder onto the deploy area.

## Payment option (new)
After the booking form (package or planned trip) there is now a payment step with:
UPI, Card, Net banking and Pay at venue.

By default this is a **simulated checkout** for the college demo:
- No real money moves. Card numbers are only checked in the browser and are never saved
  (only "Visa •••• 1111" style text is kept in the booking).
- Test card that succeeds: `4111 1111 1111 1111`, any future expiry, any CVV.
- Test card that fails: `4000 0000 0000 0002`.
- Any UPI id like `student@demo` works.
- Cancelling a paid booking marks it as refunded (demo).

### Switching on real payments (optional, Razorpay)
1. Create a free Razorpay account and copy your **Test Key ID** (starts with `rzp_test_`).
2. In `index.html`, find `const PAYMENT_CONFIG={razorpayKeyId:''` and paste the key between the quotes.
3. A "Razorpay" tab then appears at checkout. Test it with Razorpay's test cards before going live.
Note: a static site cannot verify payments securely. For real money you must also create orders and
verify the payment signature on a server. Explain this in your viva as "future work".

## What was fixed
- Sign-in accepted any email and any password; now needs a registered account and the right password.
  Added Sign out (click your name in the top bar). Admin demo still accepts any valid email + 8-char password.
- Browser Back button and page links now work (every page has its own `#address`).
- Search bar (month, travellers, trip style) was ignored; now it filters and pre-fills the planner.
- Trip planner: "Starting from", pace and food preference were ignored; now used. Each day now has its own
  activities, and removing/adding an activity affects only that day (before, it changed every day at once).
- "Save more" no longer raises your budget to hide "Over budget", and can only be applied once.
- Saving an itinerary twice no longer creates duplicates; added Delete for saved trips.
- Dashboard "Budget saved" was a fixed ₹8,400; it is now calculated from your saved trips.
- "Suggest a place" in the assistant did nothing useful; fixed. It also answers payment questions now.
- Daily cost in the destination popup was double what the planner uses; made consistent.
- Mood picker: 5-day adventure text/days/budget now match. Mobile mood grid no longer leaves a gap.
- Package filter had no results for "Family" (no such package); added one, and added Nature/Couple filters.
- Mobile menu had no way to reach "My trips"; added.
- Dates use your local day (not UTC), so booking "today" works after midnight in India.
- Names/emails typed by users are escaped (a quote in a name used to break the booking form).
- Admin "Bookings" tab shows real status (it showed Confirmed even for cancelled bookings).
- Saved data that gets corrupted no longer crashes the site.
- Image boxes show a soft colour if a photo fails to load; the toast no longer covers the assistant button;
  print/PDF output hides menus; added a page description and icon.
- Home stats: "Curated trip ideas" is now counted from real data; a note says other figures/reviews are samples.

## Images
Photos load from Unsplash. If a photo ever disappears, replace its `photo-...` id in the data lists at the top of the script.
